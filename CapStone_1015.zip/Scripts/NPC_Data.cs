using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NPC_Data : MonoBehaviour
{
   public bool isNpc;
   public int NPC_ID;

   
}
