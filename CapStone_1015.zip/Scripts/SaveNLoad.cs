using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

[System.Serializable]
public class SaveData
{
    public Vector3 playerPos;
    public Vector3 playerRot;

    public List<int> invenArrayNumber = new List<int>();
    public List<string> invenItemName = new List<string>();
    public List<int> invenItemNumber = new List<int>();

    public List<int> QuestIndex = new List<int>();
    public List<bool> isActive = new List<bool>();
    public List<bool> isAccept = new List<bool>();
    public List<bool> isClear = new List<bool>();
    
}

public class SaveNLoad : MonoBehaviour
{
    private SaveData saveData = new SaveData();

    private string SAVE_DATA_DIRECTORY;
    private string SAVE_FILENAME = "/SaveFile.txt";


    private Player thePlayer;
    private Inventory theInven;
    private QuestManager theQuest;

    // Start is called before the first frame update
    void Start()
    {
        SAVE_DATA_DIRECTORY = Application.dataPath + "/Saves/";

        //���� SAVE_DATA_DIRECTORY�� ���ٸ� ����� �ִ� ����
        if (!Directory.Exists(SAVE_DATA_DIRECTORY))
        {
            Directory.CreateDirectory(SAVE_DATA_DIRECTORY);
        }
    }


    public void SaveData()
    {
        thePlayer = FindObjectOfType<Player>();
        theInven = FindObjectOfType<Inventory>();
        theQuest = FindObjectOfType<QuestManager>();

        saveData.playerPos = thePlayer.transform.position;
        saveData.playerRot = thePlayer.transform.eulerAngles;

        Slot[] slots = theInven.GetSlots();
        for(int i =0; i<slots.Length; i++)
        {
            if(slots[i].item != null)
            {
                saveData.invenArrayNumber.Add(i);
                saveData.invenItemName.Add(slots[i].item.itemName);
                saveData.invenItemNumber.Add(slots[i].itemCount);
            }
        }

        for (int i = 0; i < 200; i += 100)
        {
            saveData.QuestIndex.Add(QuestManager.MainQuestIndex+i);
            saveData.isActive.Add(theQuest.QuestList[QuestManager.MainQuestIndex+i].isActive);
            saveData.isAccept.Add(theQuest.QuestList[QuestManager.MainQuestIndex+i].isAccept);
            saveData.isClear.Add(theQuest.QuestList[QuestManager.MainQuestIndex+i].isClear);
        }

        for (int i =0; i<theQuest.QuestList.Count-2; i++)
        {
            saveData.QuestIndex.Add(QuestManager.SubQuestIndex+i);
            saveData.isActive.Add(theQuest.QuestList[QuestManager.SubQuestIndex + i].isActive);
            saveData.isAccept.Add(theQuest.QuestList[QuestManager.SubQuestIndex + i].isAccept);
            saveData.isClear.Add(theQuest.QuestList[QuestManager.SubQuestIndex + i].isClear);
            
        }

        string json = JsonUtility.ToJson(saveData);

        File.WriteAllText(SAVE_DATA_DIRECTORY + SAVE_FILENAME, json);

        Debug.Log("���� �Ϸ�");
        Debug.Log(json);
    }

    public void LoadData()
    {
        if (File.Exists(SAVE_DATA_DIRECTORY + SAVE_FILENAME))
        {
            string LoadJson = File.ReadAllText(SAVE_DATA_DIRECTORY + SAVE_FILENAME);
            saveData = JsonUtility.FromJson<SaveData>(LoadJson);

            thePlayer = FindObjectOfType<Player>();
            theInven = FindObjectOfType<Inventory>();
            theQuest = FindObjectOfType<QuestManager>();

            thePlayer.transform.position = saveData.playerPos;
            thePlayer.transform.eulerAngles = saveData.playerRot;
            

            for(int i =0; i<saveData.invenItemName.Count; i++)
            {
                theInven.LoadToInven(saveData.invenArrayNumber[i], saveData.invenItemName[i], saveData.invenItemNumber[i]);
            }
            for(int i =0; i<saveData.QuestIndex.Count; i++)
            {               
                theQuest.LoadToQuest(saveData.QuestIndex[i], saveData.isActive[i], saveData.isAccept[i], saveData.isClear[i]);
            }

            Debug.Log("�ε� �Ϸ�");
        }
        else
        {
            Debug.Log("���� ������ �����ϴ�.");
        }
    }
}