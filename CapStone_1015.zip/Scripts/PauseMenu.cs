using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PauseMenu : MonoBehaviour
{

    public SaveNLoad save;
    // Start is called before the first frame update
    void Start()
    {
    
    }
    public void ClickSave()
    {
        save.SaveData();

    }
    public void ClickLoad()
    {
        save.LoadData();
    }
}
