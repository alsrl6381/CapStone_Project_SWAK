using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Data_NPC : MonoBehaviour
{
    public int ID;
    public bool isNPC;

}
