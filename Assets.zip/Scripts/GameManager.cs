using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    private QuestManager questManager;
    private Player player;
    private TalkManager talkManager;
    private GameObject scanObject;
    public static bool isAction;
    public GameObject talkPanel;
    public Text talkText;
    public int talkIndex;
    public Image portraitImg;

    private void Start()
    {

        talkManager = GameObject.Find("TalkManager").GetComponent<TalkManager>();
        questManager = GameObject.Find("QuestInfo").GetComponent<QuestManager>();
        player = GameObject.Find("Player").GetComponent<Player>();
        talkIndex = 0;
        
    }

    public void Action(GameObject scanObj)
    {
        isAction = true;
        scanObject = scanObj;
        NPC_Data Data = scanObject.GetComponent<NPC_Data>();
        Talk(Data.NPC_ID, Data.isNpc);
        talkPanel.SetActive(isAction);
    }

    void Talk(int id,bool isNpc)
    {
       string talkData =  talkManager.GetTalk(id, talkIndex);

        if(talkData == null)
        {
            isAction = false;
            talkIndex = 0;
            return;
        }
        if (isNpc)
        {
            talkText.text = talkData.Split(':')[0];

            portraitImg.sprite = talkManager.GetPortrait(id, int.Parse(talkData.Split(':')[1])); //  : �� �������� ��ȭ�� �ʻ�ȭ�� ������
            portraitImg.color = new Color(1, 1, 1, 1);
        }
        else
        {
            portraitImg.color = new Color(1, 1, 1, 1);
            talkText.text = talkData;

        }
        isAction = true;
        talkIndex++;
    }
    
}
