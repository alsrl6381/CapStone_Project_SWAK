using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    private QuestManager questManager;
    private Player player;
    public int CurrentChapterIndex = 0;


    private void Start()
    {
        CurrentChapterIndex = 0;
        questManager = GameObject.Find("QuestInfo").GetComponent<QuestManager>();
        player = GameObject.Find("Player").GetComponent<Player>();
        
    }
    private void Update()
    {

        questManager.QuestList[player.Player_ID+CurrentChapterIndex].goal.CheckQuestOneItem(); //�ӽ�

        questManager.QuestList[player.Player_ID + CurrentChapterIndex].goal.CheckQuestTwoItem();//�ӽ� ���ɸ��� �ٲ�� ������??

    }
}
