using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class QuestGoal
{
    public GoalType goalType;
        
    public int requiredAmount;
    public int currentAmount;
    public bool IsMeet=false;

    public bool IsReached() //������ ����Ʈ Ÿ�Ը����� �޼� ����
    {
        if (goalType == GoalType.FindOther)
        {
            return IsMeet;
        }
        else if (goalType == GoalType.Gathering)
        {
            return (currentAmount >= requiredAmount);
        }
        else return false;
    }

    public void Click()
    {
     if(goalType == GoalType.Gathering)
        {
            currentAmount++;
        }
    }

    public void Find()
    {
        if(goalType == GoalType.FindOther)
        {
            IsMeet = true;
        }
    }
    
    public enum GoalType
    {
        Gathering =10,
        FindOther = 20
    }
}
