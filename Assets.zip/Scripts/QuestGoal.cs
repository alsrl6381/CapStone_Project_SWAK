using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public class QuestGoal
{
    public GoalType goalType;
    public Inventory inventory;

    public Dictionary<string, int> Require;
    public Dictionary<string, int> Current;

    public bool IsMeet = false;

    public string[] QuestItemName;

    bool OneItemCheck;
    bool TwoItemCheck;

  

    public bool IsReached() //������ ����Ʈ Ÿ�Ը����� �޼� ����
    {

        if (goalType == GoalType.FindOther)
        {
            return IsMeet;
        }
        else if (goalType == GoalType.GatheringOneItem)
        {
            return OneItemCheck;
        }
        else if (goalType == GoalType.GatheringTwoItem) //�ʿ��� ������ ������ �������� ��� �ذ����� ������ �غ��� �� ��
        {
            return TwoItemCheck;
        }
        else 
            return false;
        }
    
    


    public void CheckQuestOneItem()
    {
        if (goalType == GoalType.GatheringOneItem) { 
        for (int i = 0; i < Inventory.CurrentItemCount; i++)
        {
            if (inventory.slots[i].item != null)
            {
                    if (inventory.slots[i].item.itemName == QuestItemName[0])
                    {
                        Current[QuestItemName[0]] = inventory.slots[i].itemCount;
                    }
            }
        }
        if ((Current[QuestItemName[0]] >= Require[QuestItemName[0]]))
        {
            OneItemCheck = true;
        }
        else OneItemCheck = false;
        }
    }

    public void CheckQuestTwoItem()
    {
        if (goalType == GoalType.GatheringTwoItem)
        {
            for (int i = 0; i < Inventory.CurrentItemCount; i++)
            {
                if (inventory.slots[i].item != null && inventory.slots[i].item.itemName == QuestItemName[0])
                {
                    Current[QuestItemName[0]] = inventory.slots[i].itemCount;
                }
                if (inventory.slots[i].item != null && inventory.slots[i].item.itemName == QuestItemName[1])
                {
                    Current[QuestItemName[1]] = inventory.slots[i].itemCount;
                }
            }
            if ((Current[QuestItemName[0]] == Require[QuestItemName[0]]) &&
                (Current[QuestItemName[1]] == Require[QuestItemName[1]]))
            {
                TwoItemCheck = true;
            }
            else TwoItemCheck = false;
        }
    }



    public void Find()
    {
        if (goalType == GoalType.FindOther)
        {
            IsMeet = true;
        }
    }

    public enum GoalType
    {
        GatheringOneItem = 10,
        GatheringTwoItem =20,
        GatheringThreeItem=30,
        FindOther = 40
    }
   
}
