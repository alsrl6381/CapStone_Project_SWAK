using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    public int CurrentChapterIndex = 0;


    private void Start()
    {
        CurrentChapterIndex = 0;

}
}
