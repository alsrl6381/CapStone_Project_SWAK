using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Rock : MonoBehaviour
{

    [SerializeField]
    private int Hp; //������ ü��

    [SerializeField]
    private float destroyTime; //v���� ���� �ð�

    [SerializeField]
    private SphereCollider col;

    //�ʿ��� ���� ������Ʈ
    [SerializeField]
    private GameObject go_rock;
    [SerializeField]
    private GameObject go_debris;

   public void Mining()
    {
        Hp--;
        if (Hp <= 0)
        {
            Destruction();
        }
    }
    private void Destruction()
    {
        col.enabled = false;
        Destroy(go_rock);

        go_debris.SetActive(true);
        Destroy(go_debris, destroyTime);
    }
}
