using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    private QuestManager questManager;
    private Player player;
   


    private void Start()
    {
    
        questManager = GameObject.Find("QuestInfo").GetComponent<QuestManager>();
        player = GameObject.Find("Player").GetComponent<Player>();
        
    }
    private void Update()
    {

      

    }
}
