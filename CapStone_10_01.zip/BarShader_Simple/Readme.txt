﻿Thank you for downloading my shader.
	
If you want to use this shader simply:
	just set the "_Fill" property from a script to a value in the range [0, 1]
		0 means empty, 1 means full.

You can also animate other properties. 
My suggestion is to check the included script, "DemoBarAnimator", and the included "Example" scene for one way of animating the bar.

Check the Properties block in the included shader file for details about what properties are available.