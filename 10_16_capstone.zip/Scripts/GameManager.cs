using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class GameManager : MonoBehaviour
{
    private QuestManager questManager;
    private Player player;
    private TalkManager talkManager;
    private GameObject scanObject;
    public static bool isAction;
    public GameObject talkPanel;
    public Text talkText;
    public int talkIndex;
    public Image portraitImg;
    public Text ItemLogText;

    private void Start()
    {

        talkManager = GameObject.Find("TalkManager").GetComponent<TalkManager>();
        questManager = GameObject.Find("QuestInfo").GetComponent<QuestManager>();
        player = GameObject.Find("Player").GetComponent<Player>();
        talkIndex = 0;
        
    }

    public void Action(GameObject scanObj)
    {
        isAction = true;
        scanObject = scanObj;
        NPC_Data Data = scanObject.GetComponent<NPC_Data>();
        Talk(Data.NPC_ID, Data.isNpc);
        talkPanel.SetActive(isAction);
    }

    void Talk(int id,bool isNpc)
    {
       string talkData =  talkManager.GetTalk(id+QuestManager.MainQuestIndex, talkIndex);

        if(talkData == null)
        {
            isAction = false;
            talkIndex = 0;
            return;
        }
        if (isNpc)
        {
            talkText.text = talkData.Split(':')[0];

            portraitImg.sprite = talkManager.GetPortrait(id+QuestManager.MainQuestIndex, int.Parse(talkData.Split(':')[1])); //  : �� �������� ��ȭ�� �ʻ�ȭ�� ������
            portraitImg.color = new Color(1, 1, 1, 1);
        }
        else
        {
            portraitImg.color = new Color(1, 1, 1, 1);
            talkText.text = talkData;

        }
        isAction = true;
        talkIndex++;
    }
    public void ItemLog(string name,int count) //�������� ��ų� �Ҿ��� �� �ߴ� �α�
    {
        string str;
        if (count > 0)
        {
            str = name + "��(��) " + count + "�� ȹ���Ͽ����ϴ�.";
            ItemLogText.text = ItemLogText.text.Insert(ItemLogText.text.Length, str + "\n");               
        }
        else
        {
            str = name + "��(��) " + -count + "�� �Ҿ����ϴ�.";
            ItemLogText.text = ItemLogText.text.Insert(ItemLogText.text.Length, str + "\n");
        }
        StartCoroutine(DeleteLog(str));
    }
    IEnumerator DeleteLog(string size)
    {
        yield return new WaitForSeconds(4f);
        ItemLogText.text=ItemLogText.text.Remove(0,size.Length+1);
        
    }
}
