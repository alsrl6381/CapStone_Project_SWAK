using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DaysAndLight : MonoBehaviour
{
    [SerializeField]
    private float secPerRealTimeSecound;

    private bool isNight = false;

    [SerializeField] private float FogDensityCalc; //������ ����

    [SerializeField]
    private float NightFogDensity; //�� ������ fog �е� 
    private float DayFogDensity; //�� ������ fog �е�

    private float CurrentFogDensity; // ���

    // Start is called before the first frame update
    void Start()
    {
        DayFogDensity = RenderSettings.fogDensity;
    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(Vector3.right, 0.1f * secPerRealTimeSecound * Time.deltaTime); //���� Ʋ���ֱ�
        if (transform.eulerAngles.x >= 170)
        {
            isNight = true;
        }else if (transform.eulerAngles.x <= 10)
        {
            isNight = false;
        }

        if (isNight)
        {
            if (CurrentFogDensity <= NightFogDensity) { 
                CurrentFogDensity += 0.1f * FogDensityCalc * Time.deltaTime;
                RenderSettings.fogDensity = CurrentFogDensity;
            }
        }
        else
        {
            if (CurrentFogDensity >= DayFogDensity)
            {
                CurrentFogDensity -= 0.1f * FogDensityCalc * Time.deltaTime;
                RenderSettings.fogDensity = CurrentFogDensity;
            }
        }
    }
}
